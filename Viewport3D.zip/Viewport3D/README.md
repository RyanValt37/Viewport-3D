# Viewport3D (Android, C++ / OpenGL ES 3 / Python)

Arsitektur:
- `cpp/engine.cpp`  : mesh (cube, UV sphere, plane), kamera orbit, picking, 3 mode shading
- `cpp/jni_bridge.cpp` + `NativeBridge.kt` : jembatan JNI
- `python/scene_api.py` : API scene (dipanggil menu UI + dialog Script) via Chaquopy
- `MainActivity.kt` / `ViewportView.kt` : UI tipis + touch

Mode shading:
1. Solid    : lighting simpel, warna objek, tanpa texture
2. Material : PBR + texture + environment langit (kayak Material Preview)
3. Render   : PBR + 3 lampu + shadow map PCF + ACES tonemap, grid disembunyiin

Build:
- Android Studio: Open folder ini -> Run (butuh NDK + CMake dari SDK Manager)
- GitHub Actions: push ke repo, workflow di `.github/workflows/build.yml` ngebuild APK debug
  (download di tab Actions -> Artifacts)

Contoh Python (tombol Script):
    add_mesh("uv_sphere"); set_color("#FF8800"); set_material(1.0, 0.2); set_position(0, 1, 0)
    set_shading("render")
