"""Scene API (Python via Chaquopy) -> engine C++.

Semua menu di UI lewat file ini, dan bisa dipanggil dari tombol "Script".
Fungsi set_* / transform berlaku ke objek yang lagi SELECTED
(objek yang baru ditambah otomatis kepilih).
"""
import io
import traceback
from contextlib import redirect_stdout

from java import jclass

_N = jclass("com.example.viewport3d.NativeBridge")

_MESH = {"cube": 0, "uv_sphere": 1, "sphere": 1, "plane": 2}
_SHADING = {"solid": 0, "material": 1, "material_preview": 1,
            "texture": 1, "render": 2, "rendered": 2}


def add_mesh(kind="cube"):
    """add_mesh('cube' | 'uv_sphere' | 'plane')"""
    key = str(kind).lower()
    if key not in _MESH:
        raise ValueError("mesh tidak dikenal: %s (pilih: cube, uv_sphere, plane)" % kind)
    _N.addMesh(_MESH[key])


def delete_selected():
    _N.deleteSelected()


def set_shading(mode="solid"):
    """set_shading('solid' | 'material' | 'render')"""
    key = str(mode).lower()
    if key not in _SHADING:
        raise ValueError("mode tidak dikenal: %s (solid, material, render)" % mode)
    _N.setShading(_SHADING[key])


def set_color(r, g=None, b=None):
    """set_color(0.9, 0.3, 0.2) atau set_color('#E6A23C')"""
    if isinstance(r, str):
        h = r.lstrip("#")
        r, g, b = (int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    _N.setColor(float(r), float(g), float(b))


def set_material(metallic=0.0, roughness=0.5):
    _N.setMaterial(float(metallic), float(roughness))


def set_texture(on=True):
    """Nyalain/matiin texture checker (kelihatan di Material & Render)."""
    _N.setTexture(bool(on))


def set_position(x, y, z):
    _N.setPosition(float(x), float(y), float(z))


def set_rotation_y(deg):
    _N.setRotationY(float(deg))


def set_scale(s):
    _N.setScale(float(s))


def startup():
    """Scene awal."""
    add_mesh("plane")
    set_position(0, -0.01, 0)
    set_scale(6)
    set_color(0.75, 0.75, 0.78)
    set_material(0.0, 0.9)

    add_mesh("cube")
    set_position(-1.8, 1.0, 0)
    set_color(0.9, 0.35, 0.25)
    set_material(0.0, 0.45)

    add_mesh("uv_sphere")
    set_position(1.8, 1.0, 0)
    set_color(0.95, 0.8, 0.3)
    set_material(1.0, 0.25)


def run_script(code):
    """Jalanin kode Python dari dialog Script. Return output / error."""
    buf = io.StringIO()
    try:
        with redirect_stdout(buf):
            exec(compile(code, "<script>", "exec"), globals())
    except Exception:
        buf.write(traceback.format_exc(limit=2))
    return buf.getvalue().strip()
