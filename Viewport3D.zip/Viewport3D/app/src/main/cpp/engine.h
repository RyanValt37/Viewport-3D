#pragma once

// Engine viewport 3D (OpenGL ES 3.0). Semua fungsi "setter" aman dipanggil dari
// thread mana pun: perintahnya diantri lalu dieksekusi di GL thread pas draw().
namespace eng {

// --- dipanggil dari GL thread ---
void create();
void resize(int w, int h);
void draw();

// --- kamera & input ---
void orbit(float dx, float dy);
void pan(float dx, float dy);
void zoom(float factor);
void pick(float x, float y);
void dragSelected(float dx, float dy);

// --- scene ---
void addMesh(int kind);          // 0 = cube, 1 = uv sphere, 2 = plane
void deleteSelected();
void setShading(int mode);       // 0 = solid, 1 = material preview, 2 = render
void setColor(float r, float g, float b);
void setMaterial(float metallic, float roughness);
void setTexture(bool on);
void setPosition(float x, float y, float z);
void setRotationY(float degrees);
void setScale(float s);
int objectCount();

}  // namespace eng
