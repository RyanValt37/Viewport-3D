#include "engine.h"

#include <GLES3/gl3.h>
#include <android/log.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <functional>
#include <mutex>
#include <string>
#include <vector>

#define LOG_TAG "Viewport3D"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

constexpr float kPi = 3.14159265358979f;
constexpr float kFov = 0.7853982f;  // 45 derajat
constexpr int kShadowSize = 2048;

// ============================ math ============================
struct V3 { float x, y, z; };
inline V3 operator+(V3 a, V3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
inline V3 operator-(V3 a, V3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
inline V3 operator*(V3 a, float s) { return {a.x * s, a.y * s, a.z * s}; }
inline float dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline V3 cross(V3 a, V3 b) {
  return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
}
inline V3 normalize(V3 a) {
  float l = std::sqrt(dot(a, a));
  return l > 1e-8f ? a * (1.f / l) : V3{0, 0, 0};
}
// rotasi sumbu Y sebesar a (radian)
inline V3 rotY(V3 p, float a) {
  float c = std::cos(a), s = std::sin(a);
  return {c * p.x + s * p.z, p.y, -s * p.x + c * p.z};
}

struct M4 { float m[16]; };  // column-major
M4 identity() { M4 r{}; r.m[0] = r.m[5] = r.m[10] = r.m[15] = 1.f; return r; }
M4 mul(const M4& a, const M4& b) {
  M4 r{};
  for (int c = 0; c < 4; c++)
    for (int row = 0; row < 4; row++) {
      float s = 0;
      for (int k = 0; k < 4; k++) s += a.m[k * 4 + row] * b.m[c * 4 + k];
      r.m[c * 4 + row] = s;
    }
  return r;
}
M4 perspective(float fovy, float aspect, float n, float f) {
  float t = 1.f / std::tan(fovy * 0.5f);
  M4 r{};
  r.m[0] = t / aspect; r.m[5] = t;
  r.m[10] = (f + n) / (n - f); r.m[11] = -1.f; r.m[14] = 2.f * f * n / (n - f);
  return r;
}
M4 ortho(float l, float r_, float b, float t, float n, float f) {
  M4 r = identity();
  r.m[0] = 2.f / (r_ - l); r.m[5] = 2.f / (t - b); r.m[10] = -2.f / (f - n);
  r.m[12] = -(r_ + l) / (r_ - l); r.m[13] = -(t + b) / (t - b); r.m[14] = -(f + n) / (f - n);
  return r;
}
M4 lookAt(V3 eye, V3 at, V3 up) {
  V3 f = normalize(at - eye), s = normalize(cross(f, up)), u = cross(s, f);
  M4 r = identity();
  r.m[0] = s.x; r.m[4] = s.y; r.m[8] = s.z;
  r.m[1] = u.x; r.m[5] = u.y; r.m[9] = u.z;
  r.m[2] = -f.x; r.m[6] = -f.y; r.m[10] = -f.z;
  r.m[12] = -dot(s, eye); r.m[13] = -dot(u, eye); r.m[14] = dot(f, eye);
  return r;
}
// T * Ry * S  (scale uniform)
M4 modelMatrix(V3 p, float ry, float s) {
  float c = std::cos(ry), sn = std::sin(ry);
  M4 r = identity();
  r.m[0] = c * s;  r.m[2] = -sn * s;
  r.m[5] = s;
  r.m[8] = sn * s; r.m[10] = c * s;
  r.m[12] = p.x; r.m[13] = p.y; r.m[14] = p.z;
  return r;
}

// ========================== geometry ==========================
// vertex: pos(3) normal(3) uv(2)
struct Geo { std::vector<float> v; std::vector<uint32_t> i; };

void addVert(Geo& g, V3 p, V3 n, float u, float v) {
  float a[8] = {p.x, p.y, p.z, n.x, n.y, n.z, u, v};
  g.v.insert(g.v.end(), a, a + 8);
}

// u x v harus = n supaya winding CCW
void addQuad(Geo& g, V3 c, V3 u, V3 v, V3 n) {
  uint32_t b = (uint32_t)(g.v.size() / 8);
  V3 p[4] = {c - u - v, c + u - v, c + u + v, c - u + v};
  float uv[4][2] = {{0, 0}, {1, 0}, {1, 1}, {0, 1}};
  for (int k = 0; k < 4; k++) addVert(g, p[k], n, uv[k][0], uv[k][1]);
  uint32_t idx[6] = {b, b + 1, b + 2, b, b + 2, b + 3};
  g.i.insert(g.i.end(), idx, idx + 6);
}

Geo makeCube() {  // ukuran 2x2x2 (kayak default cube Blender)
  Geo g;
  addQuad(g, {0, 0, 1},  {1, 0, 0},  {0, 1, 0}, {0, 0, 1});
  addQuad(g, {0, 0, -1}, {-1, 0, 0}, {0, 1, 0}, {0, 0, -1});
  addQuad(g, {1, 0, 0},  {0, 0, -1}, {0, 1, 0}, {1, 0, 0});
  addQuad(g, {-1, 0, 0}, {0, 0, 1},  {0, 1, 0}, {-1, 0, 0});
  addQuad(g, {0, 1, 0},  {1, 0, 0},  {0, 0, -1}, {0, 1, 0});
  addQuad(g, {0, -1, 0}, {1, 0, 0},  {0, 0, 1},  {0, -1, 0});
  return g;
}

Geo makePlane() {  // 2x2 di bidang XZ, normal +Y
  Geo g;
  addQuad(g, {0, 0, 0}, {1, 0, 0}, {0, 0, -1}, {0, 1, 0});
  return g;
}

Geo makeUVSphere(int segs, int rings) {  // radius 1
  Geo g;
  for (int i = 0; i <= rings; i++) {
    float th = kPi * (float)i / (float)rings;
    for (int j = 0; j <= segs; j++) {
      float ph = 2.f * kPi * (float)j / (float)segs;
      V3 p{std::sin(th) * std::cos(ph), std::cos(th), std::sin(th) * std::sin(ph)};
      addVert(g, p, p, (float)j / (float)segs, 1.f - (float)i / (float)rings);
    }
  }
  for (int i = 0; i < rings; i++)
    for (int j = 0; j < segs; j++) {
      uint32_t a = (uint32_t)(i * (segs + 1) + j), b = a + (uint32_t)segs + 1;
      uint32_t idx[6] = {a, a + 1, b, a + 1, b + 1, b};
      g.i.insert(g.i.end(), idx, idx + 6);
    }
  return g;
}

struct Mesh {
  Geo geo;
  GLuint vao = 0, vbo = 0, ebo = 0;
  GLsizei count = 0;
};

void upload(Mesh& m) {
  glGenVertexArrays(1, &m.vao);
  glBindVertexArray(m.vao);
  glGenBuffers(1, &m.vbo);
  glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
  glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(m.geo.v.size() * sizeof(float)), m.geo.v.data(), GL_STATIC_DRAW);
  glGenBuffers(1, &m.ebo);
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ebo);
  glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(m.geo.i.size() * sizeof(uint32_t)), m.geo.i.data(), GL_STATIC_DRAW);
  const GLsizei stride = 8 * sizeof(float);
  glEnableVertexAttribArray(0);
  glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
  glEnableVertexAttribArray(1);
  glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
  glEnableVertexAttribArray(2);
  glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
  glBindVertexArray(0);
  m.count = (GLsizei)m.geo.i.size();
}

// ============================ shaders ============================
const char* kPrefix =
    "#version 300 es\n"
    "precision highp float;\n"
    "precision highp int;\n"
    "precision highp sampler2D;\n"
    "precision highp sampler2DShadow;\n";

// Environment procedural (langit + matahari), dipakai bareng sama background & material
const char* kSky = R"GLSL(
uniform vec3 uKeyDir;
vec3 skyCol(vec3 d){
  vec3 hor = vec3(0.60, 0.65, 0.72), zen = vec3(0.10, 0.22, 0.55), gnd = vec3(0.12, 0.11, 0.10);
  vec3 c = d.y > 0.0 ? mix(hor, zen, pow(d.y, 0.45)) : mix(hor, gnd, pow(-d.y, 0.35));
  c += vec3(1.0, 0.85, 0.6) * pow(max(dot(d, normalize(uKeyDir)), 0.0), 400.0) * 20.0;
  return c;
}
vec3 envDiffuse(vec3 n){
  vec3 up = vec3(0.30, 0.38, 0.52), gnd = vec3(0.10, 0.095, 0.09);
  return mix(gnd, up, smoothstep(-0.6, 0.7, n.y));
}
vec3 aces(vec3 x){ return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }
)GLSL";

const char* kMeshVS = R"GLSL(
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNor;
layout(location = 2) in vec2 aUV;
uniform mat4 uVP;
uniform mat4 uModel;
uniform mat4 uLightVP;
out vec3 vWorld;
out vec3 vNor;
out vec2 vUV;
out vec4 vLightPos;
void main(){
  vec4 w = uModel * vec4(aPos, 1.0);
  vWorld = w.xyz;
  vNor = mat3(uModel) * aNor;
  vUV = aUV;
  vLightPos = uLightVP * w;
  gl_Position = uVP * w;
}
)GLSL";

const char* kMeshFS = R"GLSL(
in vec3 vWorld;
in vec3 vNor;
in vec2 vUV;
in vec4 vLightPos;
uniform int uShading;      // 0 solid, 1 material preview, 2 render
uniform vec3 uCamPos;
uniform vec3 uColor;       // sRGB
uniform float uMetal;
uniform float uRough;
uniform float uSelected;
uniform int uUseTex;
uniform sampler2D uTex;
uniform sampler2DShadow uShadow;
out vec4 outColor;

const float PI = 3.14159265;

float D_GGX(float NoH, float a){ float a2 = a * a; float d = NoH * NoH * (a2 - 1.0) + 1.0; return a2 / (PI * d * d); }
float G1(float x, float k){ return x / (x * (1.0 - k) + k); }
float G_Smith(float NoV, float NoL, float r){ float k = (r + 1.0) * (r + 1.0) / 8.0; return G1(NoV, k) * G1(NoL, k); }
vec3 F_Schlick(vec3 F0, float VoH){ return F0 + (1.0 - F0) * pow(1.0 - VoH, 5.0); }

vec3 envBRDF(vec3 F0, float rough, float NoV){
  vec4 c0 = vec4(-1.0, -0.0275, -0.572, 0.022);
  vec4 c1 = vec4(1.0, 0.0425, 1.04, -0.04);
  vec4 r = rough * c0 + c1;
  float a004 = min(r.x * r.x, exp2(-9.28 * NoV)) * r.x + r.y;
  vec2 AB = vec2(-1.04, 1.04) * a004 + r.zw;
  return F0 * AB.x + AB.y;
}

vec3 directLight(vec3 N, vec3 V, vec3 L, vec3 radiance, vec3 albedo, float metal, float rough, vec3 F0){
  vec3 H = normalize(V + L);
  float NoL = max(dot(N, L), 0.0);
  float NoV = max(dot(N, V), 1e-4);
  float NoH = max(dot(N, H), 0.0);
  float VoH = max(dot(V, H), 0.0);
  float D = D_GGX(NoH, rough * rough);
  float G = G_Smith(NoV, NoL, rough);
  vec3 F = F_Schlick(F0, VoH);
  vec3 spec = D * G * F / max(4.0 * NoV * NoL, 1e-4);
  vec3 kd = (1.0 - F) * (1.0 - metal);
  return (kd * albedo / PI + spec) * radiance * NoL;
}

float shadowFactor(vec3 N, vec3 L){
  vec3 p = vLightPos.xyz / vLightPos.w * 0.5 + 0.5;
  if (p.z > 1.0 || p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0) return 1.0;
  float bias = max(0.002 * (1.0 - dot(N, L)), 0.0005);
  vec2 ts = 1.0 / vec2(textureSize(uShadow, 0));
  float s = 0.0;
  for (int x = -1; x <= 1; x++)
    for (int y = -1; y <= 1; y++)
      s += texture(uShadow, vec3(p.xy + vec2(float(x), float(y)) * ts, p.z - bias));
  return s / 9.0;
}

void main(){
  vec3 N = normalize(vNor);
  if (!gl_FrontFacing) N = -N;
  vec3 V = normalize(uCamPos - vWorld);
  vec3 disp;

  if (uShading == 0) {
    // ---- SOLID: headlight + hemisphere, tanpa texture ----
    vec3 Lk = normalize(vec3(0.35, 0.8, 0.25));
    float key = max(dot(N, normalize(V * 0.7 + Lk)), 0.0);
    float hemi = mix(0.25, 0.55, N.y * 0.5 + 0.5);
    vec3 H = normalize(V + Lk);
    float sp = pow(max(dot(N, H), 0.0), 48.0) * 0.12;
    disp = uColor * (hemi + key * 0.55) + sp;
  } else {
    // ---- MATERIAL PREVIEW (1) / RENDER (2): PBR ----
    vec3 albedo = pow(uColor, vec3(2.2));
    if (uUseTex == 1) albedo *= pow(texture(uTex, vUV).rgb, vec3(2.2));
    float rough = clamp(uRough, 0.04, 1.0);
    vec3 F0 = mix(vec3(0.04), albedo, uMetal);
    float NoV = max(dot(N, V), 1e-4);
    vec3 R = reflect(-V, N);

    vec3 irr = envDiffuse(N);
    vec3 prefilt = mix(skyCol(R), envDiffuse(R), rough * rough);
    vec3 ab = envBRDF(F0, rough, NoV);
    vec3 kd = (1.0 - ab) * (1.0 - uMetal);
    vec3 ambient = kd * albedo * irr + prefilt * ab;

    vec3 Lk = normalize(uKeyDir);
    float sh = 1.0;
    vec3 col;
    if (uShading == 2) {
      sh = shadowFactor(N, Lk);
      col = ambient * mix(0.55, 1.0, sh);
      col += directLight(N, V, Lk, vec3(1.0, 0.95, 0.85) * 4.0 * sh, albedo, uMetal, rough, F0);
      vec3 Lf = normalize(vec3(-Lk.x, 0.3, -Lk.z * 0.3));
      col += directLight(N, V, Lf, vec3(0.55, 0.65, 0.9) * 0.9, albedo, uMetal, rough, F0);
      vec3 Lr = normalize(vec3(-0.6, 0.5, -0.8));
      col += directLight(N, V, Lr, vec3(1.0) * 1.2, albedo, uMetal, rough, F0);
    } else {
      col = ambient;
      col += directLight(N, V, Lk, vec3(1.0, 0.95, 0.85) * 2.5, albedo, uMetal, rough, F0);
    }
    disp = pow(aces(col), vec3(1.0 / 2.2));
  }

  if (uSelected > 0.5) {
    float f = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 2.5);
    disp = mix(disp, vec3(1.0, 0.6, 0.1), clamp(f * 0.9 + 0.10, 0.0, 1.0));
  }
  outColor = vec4(disp, 1.0);
}
)GLSL";

const char* kDepthVS = R"GLSL(
layout(location = 0) in vec3 aPos;
uniform mat4 uLightVP;
uniform mat4 uModel;
void main(){ gl_Position = uLightVP * uModel * vec4(aPos, 1.0); }
)GLSL";
const char* kDepthFS = "void main(){}\n";

const char* kGridVS = R"GLSL(
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aCol;
uniform mat4 uVP;
out vec3 vCol;
out vec3 vW;
void main(){ vCol = aCol; vW = aPos; gl_Position = uVP * vec4(aPos, 1.0); }
)GLSL";
const char* kGridFS = R"GLSL(
in vec3 vCol;
in vec3 vW;
out vec4 o;
void main(){
  float a = clamp(1.0 - length(vW.xz) / 22.0, 0.0, 1.0);
  o = vec4(vCol, a);
}
)GLSL";

const char* kBgVS = R"GLSL(
out vec2 vNdc;
void main(){
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  vNdc = p * 2.0 - 1.0;
  gl_Position = vec4(vNdc, 0.9999, 1.0);
}
)GLSL";
const char* kBgFS = R"GLSL(
in vec2 vNdc;
uniform vec3 uRight;
uniform vec3 uUp;
uniform vec3 uFwd;
uniform vec2 uTan;
out vec4 o;
void main(){
  vec3 d = normalize(uFwd + uRight * (vNdc.x * uTan.x) + uUp * (vNdc.y * uTan.y));
  vec3 c = aces(skyCol(d) * 0.9);
  o = vec4(pow(c, vec3(1.0 / 2.2)), 1.0);
}
)GLSL";

GLuint compile(GLenum type, const std::string& src) {
  GLuint s = glCreateShader(type);
  const char* p = src.c_str();
  glShaderSource(s, 1, &p, nullptr);
  glCompileShader(s);
  GLint ok = 0;
  glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
  if (!ok) {
    char log[2048];
    glGetShaderInfoLog(s, sizeof(log), nullptr, log);
    LOGE("shader compile error: %s", log);
  }
  return s;
}

GLuint makeProgram(const std::string& vs, const std::string& fs) {
  GLuint v = compile(GL_VERTEX_SHADER, std::string(kPrefix) + vs);
  GLuint f = compile(GL_FRAGMENT_SHADER, std::string(kPrefix) + fs);
  GLuint p = glCreateProgram();
  glAttachShader(p, v);
  glAttachShader(p, f);
  glLinkProgram(p);
  GLint ok = 0;
  glGetProgramiv(p, GL_LINK_STATUS, &ok);
  if (!ok) {
    char log[2048];
    glGetProgramInfoLog(p, sizeof(log), nullptr, log);
    LOGE("program link error: %s", log);
  }
  glDeleteShader(v);
  glDeleteShader(f);
  return p;
}

inline GLint loc(GLuint p, const char* n) { return glGetUniformLocation(p, n); }

GLuint makeChecker() {
  const int N = 512;
  std::vector<uint8_t> px((size_t)N * N * 4);
  for (int y = 0; y < N; y++)
    for (int x = 0; x < N; x++) {
      int c = ((x / 32) + (y / 32)) & 1;
      uint8_t v = c ? 140 : 235;
      size_t k = ((size_t)y * N + x) * 4;
      px[k] = px[k + 1] = px[k + 2] = v;
      px[k + 3] = 255;
    }
  GLuint t = 0;
  glGenTextures(1, &t);
  glBindTexture(GL_TEXTURE_2D, t);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, N, N, 0, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
  glGenerateMipmap(GL_TEXTURE_2D);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  return t;
}

// ============================ scene state ============================
struct Obj {
  int kind = 0;
  V3 pos{0, 0, 0};
  float rotY = 0.f;  // radian
  float scale = 1.f;
  V3 color{0.8f, 0.8f, 0.8f};
  float metal = 0.f, rough = 0.5f;
  bool tex = true;
};

struct State {
  int w = 1, h = 1;
  int shading = 0;
  float yaw = 0.8f, pitch = 0.45f, dist = 10.f;
  V3 target{0, 0.5f, 0};
  std::vector<Obj> objs;
  int selected = -1;
  Mesh meshes[3];
  GLuint progMesh = 0, progDepth = 0, progGrid = 0, progBg = 0;
  GLuint texChecker = 0, texShadow = 0, fbo = 0, vaoEmpty = 0, gridVao = 0, gridVbo = 0;
  GLsizei gridCount = 0;
};
State S;

std::mutex gMu;
std::vector<std::function<void()>> gQueue;
std::atomic<int> gCount{0};

void post(std::function<void()> f) {
  std::lock_guard<std::mutex> l(gMu);
  gQueue.push_back(std::move(f));
}

V3 camEye() {
  return S.target + V3{std::cos(S.pitch) * std::sin(S.yaw), std::sin(S.pitch),
                       std::cos(S.pitch) * std::cos(S.yaw)} * S.dist;
}
struct CamBasis { V3 eye, fwd, right, up; };
CamBasis camBasis() {
  CamBasis c;
  c.eye = camEye();
  c.fwd = normalize(S.target - c.eye);
  c.right = normalize(cross(c.fwd, V3{0, 1, 0}));
  c.up = cross(c.right, c.fwd);
  return c;
}
float pixelToWorld() { return S.dist * 2.f * std::tan(kFov * 0.5f) / (float)S.h; }

// ---- picking (ray vs segitiga, di local space tiap objek) ----
bool rayTri(V3 o, V3 d, V3 a, V3 b, V3 c, float& t) {
  V3 e1 = b - a, e2 = c - a, p = cross(d, e2);
  float det = dot(e1, p);
  if (std::fabs(det) < 1e-9f) return false;
  float inv = 1.f / det;
  V3 s = o - a;
  float u = dot(s, p) * inv;
  if (u < 0.f || u > 1.f) return false;
  V3 q = cross(s, e1);
  float v = dot(d, q) * inv;
  if (v < 0.f || u + v > 1.f) return false;
  t = dot(e2, q) * inv;
  return t > 1e-4f;
}
V3 vtx(const Geo& g, uint32_t i) { return {g.v[i * 8], g.v[i * 8 + 1], g.v[i * 8 + 2]}; }

void pickAt(float px, float py) {
  CamBasis c = camBasis();
  float th = std::tan(kFov * 0.5f), aspect = (float)S.w / (float)S.h;
  float nx = 2.f * px / (float)S.w - 1.f, ny = 1.f - 2.f * py / (float)S.h;
  V3 d = normalize(c.fwd + c.right * (nx * th * aspect) + c.up * (ny * th));
  int best = -1;
  float bestT = 1e30f;
  for (size_t i = 0; i < S.objs.size(); i++) {
    const Obj& o = S.objs[i];
    const Geo& g = S.meshes[o.kind].geo;
    V3 lo = rotY(c.eye - o.pos, -o.rotY) * (1.f / o.scale);
    V3 ld = rotY(d, -o.rotY) * (1.f / o.scale);
    for (size_t t = 0; t + 2 < g.i.size(); t += 3) {
      float tt;
      if (rayTri(lo, ld, vtx(g, g.i[t]), vtx(g, g.i[t + 1]), vtx(g, g.i[t + 2]), tt) && tt < bestT) {
        bestT = tt;
        best = (int)i;
      }
    }
  }
  S.selected = best;
}

void drawObjects(GLuint prog, bool shadowPass) {
  for (size_t i = 0; i < S.objs.size(); i++) {
    const Obj& o = S.objs[i];
    M4 mdl = modelMatrix(o.pos, o.rotY, o.scale);
    glUniformMatrix4fv(loc(prog, "uModel"), 1, GL_FALSE, mdl.m);
    if (!shadowPass) {
      glUniform3f(loc(prog, "uColor"), o.color.x, o.color.y, o.color.z);
      glUniform1f(loc(prog, "uMetal"), o.metal);
      glUniform1f(loc(prog, "uRough"), o.rough);
      glUniform1i(loc(prog, "uUseTex"), o.tex ? 1 : 0);
      glUniform1f(loc(prog, "uSelected"), (int)i == S.selected ? 1.f : 0.f);
    }
    const Mesh& m = S.meshes[o.kind];
    glBindVertexArray(m.vao);
    glDrawElements(GL_TRIANGLES, m.count, GL_UNSIGNED_INT, nullptr);
  }
  glBindVertexArray(0);
}

}  // namespace

// ============================ public API ============================
namespace eng {

void create() {
  // dipanggil tiap GL context baru dibuat (termasuk habis app di-resume)
  S.meshes[0] = Mesh(); S.meshes[0].geo = makeCube();
  S.meshes[1] = Mesh(); S.meshes[1].geo = makeUVSphere(32, 16);
  S.meshes[2] = Mesh(); S.meshes[2].geo = makePlane();
  for (auto& m : S.meshes) upload(m);

  S.progMesh = makeProgram(kMeshVS, std::string(kSky) + kMeshFS);
  S.progDepth = makeProgram(kDepthVS, kDepthFS);
  S.progGrid = makeProgram(kGridVS, kGridFS);
  S.progBg = makeProgram(kBgVS, std::string(kSky) + kBgFS);
  S.texChecker = makeChecker();

  // shadow map
  glGenTextures(1, &S.texShadow);
  glBindTexture(GL_TEXTURE_2D, S.texShadow);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, kShadowSize, kShadowSize, 0,
               GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
  glGenFramebuffers(1, &S.fbo);
  glBindFramebuffer(GL_FRAMEBUFFER, S.fbo);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, S.texShadow, 0);
  GLenum none = GL_NONE;
  glDrawBuffers(1, &none);
  glReadBuffer(GL_NONE);
  if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) LOGE("shadow FBO incomplete");
  glBindFramebuffer(GL_FRAMEBUFFER, 0);

  glGenVertexArrays(1, &S.vaoEmpty);

  // grid 40x40
  std::vector<float> gv;
  auto line = [&](V3 a, V3 b, V3 c) {
    float t[12] = {a.x, a.y, a.z, c.x, c.y, c.z, b.x, b.y, b.z, c.x, c.y, c.z};
    gv.insert(gv.end(), t, t + 12);
  };
  const V3 gray{0.38f, 0.38f, 0.40f}, red{0.75f, 0.25f, 0.25f}, blue{0.30f, 0.45f, 0.90f};
  for (int i = -20; i <= 20; i++) {
    line({-20, 0, (float)i}, {20, 0, (float)i}, i == 0 ? red : gray);   // sumbu X
    line({(float)i, 0, -20}, {(float)i, 0, 20}, i == 0 ? blue : gray);  // sumbu Z
  }
  S.gridCount = (GLsizei)(gv.size() / 6);
  glGenVertexArrays(1, &S.gridVao);
  glBindVertexArray(S.gridVao);
  glGenBuffers(1, &S.gridVbo);
  glBindBuffer(GL_ARRAY_BUFFER, S.gridVbo);
  glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(gv.size() * sizeof(float)), gv.data(), GL_STATIC_DRAW);
  glEnableVertexAttribArray(0);
  glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
  glEnableVertexAttribArray(1);
  glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
  glBindVertexArray(0);
}

void resize(int w, int h) {
  S.w = std::max(w, 1);
  S.h = std::max(h, 1);
  glViewport(0, 0, S.w, S.h);
}

void draw() {
  // 1) jalanin perintah yang diantri dari UI/Python
  std::vector<std::function<void()>> cmds;
  {
    std::lock_guard<std::mutex> l(gMu);
    cmds.swap(gQueue);
  }
  for (auto& f : cmds) f();
  if (!S.progMesh) return;

  CamBasis c = camBasis();
  float aspect = (float)S.w / (float)S.h;
  M4 view = lookAt(c.eye, S.target, V3{0, 1, 0});
  M4 proj = perspective(kFov, aspect, 0.1f, 300.f);
  M4 vp = mul(proj, view);

  V3 keyDir = normalize(V3{0.45f, 0.8f, 0.35f});
  M4 lvp = mul(ortho(-14, 14, -14, 14, 1, 70), lookAt(keyDir * 30.f, V3{0, 0, 0}, V3{0, 1, 0}));

  glEnable(GL_DEPTH_TEST);
  glDepthFunc(GL_LEQUAL);
  glDisable(GL_CULL_FACE);  // plane double-sided; normal di-flip di shader

  // 2) shadow pass (cuma mode Render)
  if (S.shading == 2) {
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, 0);
    glBindFramebuffer(GL_FRAMEBUFFER, S.fbo);
    glViewport(0, 0, kShadowSize, kShadowSize);
    glClear(GL_DEPTH_BUFFER_BIT);
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(2.f, 4.f);
    glUseProgram(S.progDepth);
    glUniformMatrix4fv(loc(S.progDepth, "uLightVP"), 1, GL_FALSE, lvp.m);
    drawObjects(S.progDepth, true);
    glDisable(GL_POLYGON_OFFSET_FILL);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
  }

  // 3) main pass
  glViewport(0, 0, S.w, S.h);
  glClearColor(0.23f, 0.23f, 0.24f, 1.f);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  if (S.shading != 0) {  // background langit
    float th = std::tan(kFov * 0.5f);
    glDisable(GL_DEPTH_TEST);
    glUseProgram(S.progBg);
    glUniform3f(loc(S.progBg, "uRight"), c.right.x, c.right.y, c.right.z);
    glUniform3f(loc(S.progBg, "uUp"), c.up.x, c.up.y, c.up.z);
    glUniform3f(loc(S.progBg, "uFwd"), c.fwd.x, c.fwd.y, c.fwd.z);
    glUniform2f(loc(S.progBg, "uTan"), th * aspect, th);
    glUniform3f(loc(S.progBg, "uKeyDir"), keyDir.x, keyDir.y, keyDir.z);
    glBindVertexArray(S.vaoEmpty);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
  }

  if (S.shading != 2) {  // grid (disembunyiin di Render biar bersih)
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glUseProgram(S.progGrid);
    glUniformMatrix4fv(loc(S.progGrid, "uVP"), 1, GL_FALSE, vp.m);
    glBindVertexArray(S.gridVao);
    glDrawArrays(GL_LINES, 0, S.gridCount);
    glBindVertexArray(0);
    glDisable(GL_BLEND);
  }

  glUseProgram(S.progMesh);
  glUniformMatrix4fv(loc(S.progMesh, "uVP"), 1, GL_FALSE, vp.m);
  glUniformMatrix4fv(loc(S.progMesh, "uLightVP"), 1, GL_FALSE, lvp.m);
  glUniform3f(loc(S.progMesh, "uCamPos"), c.eye.x, c.eye.y, c.eye.z);
  glUniform3f(loc(S.progMesh, "uKeyDir"), keyDir.x, keyDir.y, keyDir.z);
  glUniform1i(loc(S.progMesh, "uShading"), S.shading);
  glUniform1i(loc(S.progMesh, "uTex"), 0);
  glUniform1i(loc(S.progMesh, "uShadow"), 1);
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, S.texChecker);
  glActiveTexture(GL_TEXTURE1);
  glBindTexture(GL_TEXTURE_2D, S.texShadow);
  drawObjects(S.progMesh, false);
}

// ---------------- kamera & input ----------------
void orbit(float dx, float dy) {
  post([=] {
    S.yaw -= dx * 0.01f;
    S.pitch = std::min(1.5f, std::max(-1.5f, S.pitch + dy * 0.01f));
  });
}
void pan(float dx, float dy) {
  post([=] {
    CamBasis c = camBasis();
    float k = pixelToWorld();
    S.target = S.target + c.right * (-dx * k) + c.up * (dy * k);
  });
}
void zoom(float f) {
  post([=] { S.dist = std::min(80.f, std::max(1.5f, S.dist * f)); });
}
void pick(float x, float y) {
  post([=] { pickAt(x, y); });
}
void dragSelected(float dx, float dy) {
  post([=] {
    if (S.selected < 0 || S.selected >= (int)S.objs.size()) return;
    CamBasis c = camBasis();
    V3 r = normalize(V3{c.right.x, 0, c.right.z});
    V3 f = normalize(V3{c.fwd.x, 0, c.fwd.z});
    float k = pixelToWorld();
    Obj& o = S.objs[S.selected];
    o.pos = o.pos + r * (dx * k) + f * (-dy * k);
  });
}

// ---------------- scene ----------------
void addMesh(int kind) {
  post([=] {
    if (kind < 0 || kind > 2) return;
    Obj o;
    o.kind = kind;
    S.objs.push_back(o);
    S.selected = (int)S.objs.size() - 1;
    gCount = (int)S.objs.size();
  });
}
void deleteSelected() {
  post([] {
    if (S.selected < 0 || S.selected >= (int)S.objs.size()) return;
    S.objs.erase(S.objs.begin() + S.selected);
    S.selected = -1;
    gCount = (int)S.objs.size();
  });
}
void setShading(int mode) {
  post([=] { S.shading = std::min(2, std::max(0, mode)); });
}

#define WITH_SELECTED(...)                                                   \
  post([=] {                                                                 \
    if (S.selected < 0 || S.selected >= (int)S.objs.size()) return;          \
    Obj& o = S.objs[S.selected];                                             \
    __VA_ARGS__                                                              \
  })

void setColor(float r, float g, float b) { WITH_SELECTED(o.color = V3{r, g, b};); }
void setMaterial(float metallic, float roughness) {
  WITH_SELECTED(o.metal = std::min(1.f, std::max(0.f, metallic));
                o.rough = std::min(1.f, std::max(0.f, roughness)););
}
void setTexture(bool on) { WITH_SELECTED(o.tex = on;); }
void setPosition(float x, float y, float z) { WITH_SELECTED(o.pos = V3{x, y, z};); }
void setRotationY(float degrees) { WITH_SELECTED(o.rotY = degrees * kPi / 180.f;); }
void setScale(float s) { WITH_SELECTED(o.scale = std::max(0.01f, s);); }

int objectCount() { return gCount.load(); }

}  // namespace eng
