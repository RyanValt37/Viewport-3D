#include <jni.h>
#include "engine.h"

#define FN(name) Java_com_example_viewport3d_NativeBridge_##name

extern "C" {

JNIEXPORT void JNICALL FN(create)(JNIEnv*, jclass) { eng::create(); }
JNIEXPORT void JNICALL FN(resize)(JNIEnv*, jclass, jint w, jint h) { eng::resize(w, h); }
JNIEXPORT void JNICALL FN(draw)(JNIEnv*, jclass) { eng::draw(); }

JNIEXPORT void JNICALL FN(orbit)(JNIEnv*, jclass, jfloat dx, jfloat dy) { eng::orbit(dx, dy); }
JNIEXPORT void JNICALL FN(pan)(JNIEnv*, jclass, jfloat dx, jfloat dy) { eng::pan(dx, dy); }
JNIEXPORT void JNICALL FN(zoom)(JNIEnv*, jclass, jfloat f) { eng::zoom(f); }
JNIEXPORT void JNICALL FN(pick)(JNIEnv*, jclass, jfloat x, jfloat y) { eng::pick(x, y); }
JNIEXPORT void JNICALL FN(dragSelected)(JNIEnv*, jclass, jfloat dx, jfloat dy) { eng::dragSelected(dx, dy); }

JNIEXPORT void JNICALL FN(addMesh)(JNIEnv*, jclass, jint kind) { eng::addMesh(kind); }
JNIEXPORT void JNICALL FN(deleteSelected)(JNIEnv*, jclass) { eng::deleteSelected(); }
JNIEXPORT void JNICALL FN(setShading)(JNIEnv*, jclass, jint mode) { eng::setShading(mode); }
JNIEXPORT void JNICALL FN(setColor)(JNIEnv*, jclass, jfloat r, jfloat g, jfloat b) { eng::setColor(r, g, b); }
JNIEXPORT void JNICALL FN(setMaterial)(JNIEnv*, jclass, jfloat m, jfloat r) { eng::setMaterial(m, r); }
JNIEXPORT void JNICALL FN(setTexture)(JNIEnv*, jclass, jboolean on) { eng::setTexture(on == JNI_TRUE); }
JNIEXPORT void JNICALL FN(setPosition)(JNIEnv*, jclass, jfloat x, jfloat y, jfloat z) { eng::setPosition(x, y, z); }
JNIEXPORT void JNICALL FN(setRotationY)(JNIEnv*, jclass, jfloat d) { eng::setRotationY(d); }
JNIEXPORT void JNICALL FN(setScale)(JNIEnv*, jclass, jfloat s) { eng::setScale(s); }
JNIEXPORT jint JNICALL FN(objectCount)(JNIEnv*, jclass) { return eng::objectCount(); }

}  // extern "C"
