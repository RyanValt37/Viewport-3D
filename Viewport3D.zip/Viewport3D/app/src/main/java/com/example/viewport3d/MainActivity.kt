package com.example.viewport3d

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Toast
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

class MainActivity : Activity() {

    private lateinit var viewport: ViewportView
    private val py by lazy { Python.getInstance().getModule("scene_api") }
    private val modeButtons = mutableListOf<Button>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))

        viewport = ViewportView(this)
        val root = FrameLayout(this)
        root.addView(viewport)

        // ---- top bar: Add | Delete | Move | Script ----
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val addBtn = button("+ Add") { showAddMenu(it) }
        val delBtn = button("Delete") { py.callAttr("delete_selected") }
        val moveBtn = button("Move: off") {}
        moveBtn.setOnClickListener {
            viewport.moveTool = !viewport.moveTool
            moveBtn.text = if (viewport.moveTool) "Move: on" else "Move: off"
        }
        val scriptBtn = button("Script") { showScriptDialog() }
        listOf(addBtn, delBtn, moveBtn, scriptBtn).forEach { top.addView(it) }
        root.addView(top, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.START))

        // ---- bottom bar: Solid | Material | Render ----
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val modes = listOf("Solid" to "solid", "Material" to "material", "Render" to "render")
        modes.forEachIndexed { i, (label, key) ->
            val b = button(label) {
                py.callAttr("set_shading", key)
                highlightMode(i)
            }
            modeButtons.add(b)
            bottom.addView(b)
        }
        root.addView(bottom, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        highlightMode(0)

        setContentView(root)

        if (NativeBridge.objectCount() == 0) py.callAttr("startup")
    }

    private fun button(label: String, onClick: (Button) -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 13f
            setOnClickListener { onClick(this) }
        }

    private fun highlightMode(active: Int) {
        modeButtons.forEachIndexed { i, b -> b.alpha = if (i == active) 1f else 0.5f }
    }

    private fun showAddMenu(anchor: Button) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 0, 0, "Cube")
        menu.menu.add(0, 1, 1, "UV Sphere")
        menu.menu.add(0, 2, 2, "Plane")
        menu.setOnMenuItemClickListener { item ->
            val kind = when (item.itemId) {
                0 -> "cube"
                1 -> "uv_sphere"
                else -> "plane"
            }
            py.callAttr("add_mesh", kind)
            true
        }
        menu.show()
    }

    private fun showScriptDialog() {
        val input = EditText(this).apply {
            setText("add_mesh(\"cube\")\nset_color(\"#3399FF\")\nset_position(0, 1, 3)\nset_material(0.0, 0.3)")
            typeface = Typeface.MONOSPACE
            textSize = 13f
            gravity = Gravity.TOP or Gravity.START
            minLines = 6
        }
        AlertDialog.Builder(this)
            .setTitle("Python script")
            .setView(input)
            .setPositiveButton("Run") { _, _ ->
                val out = py.callAttr("run_script", input.text.toString()).toString()
                if (out.isNotBlank()) Toast.makeText(this, out, Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    override fun onPause() { super.onPause(); viewport.onPause() }
    override fun onResume() { super.onResume(); viewport.onResume() }
}
