package com.example.viewport3d

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Viewport 3D.
 *  - 1 jari geser  : orbit (atau geser objek kalau Move aktif)
 *  - 2 jari cubit  : zoom
 *  - 2 jari geser  : pan
 *  - tap           : pilih objek
 */
class ViewportView(ctx: Context) : GLSurfaceView(ctx) {
    var moveTool = false

    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var lastDist = 0f
    private var lastMidX = 0f
    private var lastMidY = 0f
    private var moved = false
    private var multi = false

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 24, 0)
        setRenderer(object : GLSurfaceView.Renderer {
            override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) = NativeBridge.create()
            override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) = NativeBridge.resize(w, h)
            override fun onDrawFrame(gl: GL10?) = NativeBridge.draw()
        })
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    private fun dist(e: MotionEvent) = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x; lastY = e.y
                downX = e.x; downY = e.y
                moved = false; multi = false
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                multi = true
                if (e.pointerCount == 2) {
                    lastDist = dist(e)
                    lastMidX = (e.getX(0) + e.getX(1)) / 2
                    lastMidY = (e.getY(0) + e.getY(1)) / 2
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount >= 2) {
                    val d = dist(e)
                    val mx = (e.getX(0) + e.getX(1)) / 2
                    val my = (e.getY(0) + e.getY(1)) / 2
                    if (lastDist > 0f && d > 0f) NativeBridge.zoom(lastDist / d)
                    NativeBridge.pan(mx - lastMidX, my - lastMidY)
                    lastDist = d; lastMidX = mx; lastMidY = my
                } else if (!multi) {
                    if (abs(e.x - downX) + abs(e.y - downY) > 12f) moved = true
                    if (moved) {
                        val dx = e.x - lastX
                        val dy = e.y - lastY
                        if (moveTool) NativeBridge.dragSelected(dx, dy) else NativeBridge.orbit(dx, dy)
                    }
                    lastX = e.x; lastY = e.y
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!moved && !multi) NativeBridge.pick(e.x, e.y)
            }
        }
        return true
    }
}
