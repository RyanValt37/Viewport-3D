package com.example.viewport3d

/** Jembatan JNI ke engine C++. Python juga manggil object ini lewat scene_api.py. */
object NativeBridge {
    init { System.loadLibrary("viewport3d") }

    // dipanggil GL thread
    @JvmStatic external fun create()
    @JvmStatic external fun resize(w: Int, h: Int)
    @JvmStatic external fun draw()

    // kamera & input
    @JvmStatic external fun orbit(dx: Float, dy: Float)
    @JvmStatic external fun pan(dx: Float, dy: Float)
    @JvmStatic external fun zoom(factor: Float)
    @JvmStatic external fun pick(x: Float, y: Float)
    @JvmStatic external fun dragSelected(dx: Float, dy: Float)

    // scene
    @JvmStatic external fun addMesh(kind: Int)          // 0 cube, 1 uv sphere, 2 plane
    @JvmStatic external fun deleteSelected()
    @JvmStatic external fun setShading(mode: Int)       // 0 solid, 1 material, 2 render
    @JvmStatic external fun setColor(r: Float, g: Float, b: Float)
    @JvmStatic external fun setMaterial(metallic: Float, roughness: Float)
    @JvmStatic external fun setTexture(on: Boolean)
    @JvmStatic external fun setPosition(x: Float, y: Float, z: Float)
    @JvmStatic external fun setRotationY(degrees: Float)
    @JvmStatic external fun setScale(s: Float)
    @JvmStatic external fun objectCount(): Int
}
